package com.example.niharbuliya_habbit_tracker

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
